# Python Setup

```
pip3 install mysql-connector-python hvac python3-flask