# Instructions
Install flask and MySQL connector:
```
pip3 install Flask mysql-connector-python
```

## Configuration

The application reads a file named "config.ini" when it starts.  Database location, credentials, etc, are contained therein.
