# files directory
Use this directory to add files that need to be available to sandbox VMs at runtime.

This files directory will be copied to the following location of the VM sandbox at runtime:
```
/opt/vcdl/files
```

